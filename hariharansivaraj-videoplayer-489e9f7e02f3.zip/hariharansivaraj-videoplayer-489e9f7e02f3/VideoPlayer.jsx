import React, { useRef, useState, useEffect } from "react";
import { 
  FaPlay, 
  FaPause, 
  FaVolumeMute, 
  FaVolumeUp,
  FaExpand,
  FaCompress,
  FaCog,
  FaTheaterMasks,
  FaRegWindowRestore,
  FaForward,
  FaBackward,
  FaShare,
  FaFacebookF,
  FaTwitter,
  FaLinkedinIn,
  FaLink,
  FaCode,
  FaTimes,
  FaWindowRestore
} from "react-icons/fa";
import { 
  MdOutlineCropSquare, 
  MdOutlineCropLandscape 
} from "react-icons/md";
import { debounce } from 'lodash';

const VideoPlayer = ({ videoId, videoSrc, title, thumbnail, onTimeUpdate }) => {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const [isHovering, setIsHovering] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [quality, setQuality] = useState('auto');
  const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
  const [showCopyConfirmation, setShowCopyConfirmation] = useState(false);
  const shareMenuRef = useRef(null);
  const [hoveredControl, setHoveredControl] = useState(null);
  const [showKeyboardShortcuts, setShowKeyboardShortcuts] = useState(false);
  const [hoverTime, setHoverTime] = useState(null);
  const [hoverPosition, setHoverPosition] = useState(null);
  const progressBarRef = useRef(null);
  const [isMiniPlayer, setIsMiniPlayer] = useState(false);
  const [shouldResumeTime, setShouldResumeTime] = useState(null);
  const [lastSavedTime, setLastSavedTime] = useState(0);

  // Format time in MM:SS
  const formatTime = (timeInSeconds) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Helper function to format time for preview
  const formatPreviewTime = (time) => {
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = Math.floor(time % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Helper to log events
  const log = (event, details = {}) => {
    console.log(`[VideoPlayer] ${event}`, details);
  };

  useEffect(() => {
    let timeout;
    if (isHovering) {
      setShowControls(true);
    } else {
      timeout = setTimeout(() => {
        if (!isSettingsOpen && !isPlaying) {
          setShowControls(false);
        }
      }, 2000);
    }
    return () => clearTimeout(timeout);
  }, [isHovering, isSettingsOpen, isPlaying]);

  // Add click outside handler for share menu
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (shareMenuRef.current && !shareMenuRef.current.contains(event.target)) {
        setIsShareMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Add keyboard event listener
  useEffect(() => {
    const handleKeyPress = (e) => {
      // Ignore key events if user is typing in an input field
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      switch (e.key.toLowerCase()) {
        case ' ':
        case 'k':
          // Space or K - Play/Pause
          e.preventDefault();
          togglePlay();
          break;
        
        case 'f':
          // F - Toggle fullscreen
          e.preventDefault();
          toggleFullscreen();
          break;
        
        case 't':
          // T - Toggle theater mode
          e.preventDefault();
          toggleTheaterMode();
          break;
        
        case 'm':
          // M - Toggle mute
          e.preventDefault();
          toggleMute();
          break;
        
        case 'arrowleft':
          // Left arrow - Rewind 5 seconds
          e.preventDefault();
          if (videoRef.current) {
            videoRef.current.currentTime -= 5;
            log("keyboard-rewind", { seconds: 5 });
          }
          break;
        
        case 'arrowright':
          // Right arrow - Forward 5 seconds
          e.preventDefault();
          if (videoRef.current) {
            videoRef.current.currentTime += 5;
            log("keyboard-forward", { seconds: 5 });
          }
          break;
        
        case 'arrowup':
          // Up arrow - Volume up
          e.preventDefault();
          if (videoRef.current) {
            const newVolume = Math.min(1, videoRef.current.volume + 0.05);
            videoRef.current.volume = newVolume;
            setVolume(newVolume);
            setIsMuted(false);
            log("keyboard-volume-up", { volume: newVolume });
          }
          break;
        
        case 'arrowdown':
          // Down arrow - Volume down
          e.preventDefault();
          if (videoRef.current) {
            const newVolume = Math.max(0, videoRef.current.volume - 0.05);
            videoRef.current.volume = newVolume;
            setVolume(newVolume);
            setIsMuted(newVolume === 0);
            log("keyboard-volume-down", { volume: newVolume });
          }
          break;
        
        case 'c':
          // C - Toggle captions (if implemented)
          e.preventDefault();
          // Add captions toggle logic here
          break;
        
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          // Number keys - Skip to percentage of video
          e.preventDefault();
          if (videoRef.current) {
            const percent = parseInt(e.key) * 10;
            const newTime = (videoRef.current.duration * percent) / 100;
            videoRef.current.currentTime = newTime;
            log("keyboard-seek", { percent, time: newTime });
          }
          break;
        
        case 'j':
          // J - Rewind 10 seconds
          e.preventDefault();
          if (videoRef.current) {
            videoRef.current.currentTime -= 10;
            log("keyboard-rewind", { seconds: 10 });
          }
          break;
        
        case 'l':
          // L - Forward 10 seconds
          e.preventDefault();
          if (videoRef.current) {
            videoRef.current.currentTime += 10;
            log("keyboard-forward", { seconds: 10 });
          }
          break;
        
        case '<':
        case ',':
          // < or , - Decrease playback speed
          e.preventDefault();
          if (videoRef.current) {
            const newSpeed = Math.max(0.25, videoRef.current.playbackRate - 0.25);
            videoRef.current.playbackRate = newSpeed;
            setPlaybackSpeed(newSpeed);
            log("keyboard-speed-down", { speed: newSpeed });
          }
          break;
        
        case '>':
        case '.':
          // > or . - Increase playback speed
          e.preventDefault();
          if (videoRef.current) {
            const newSpeed = Math.min(2, videoRef.current.playbackRate + 0.25);
            videoRef.current.playbackRate = newSpeed;
            setPlaybackSpeed(newSpeed);
            log("keyboard-speed-up", { speed: newSpeed });
          }
          break;
        
        case '?':
        case '/':
          // ? or / - Show keyboard shortcuts
          e.preventDefault();
          setShowKeyboardShortcuts(true);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isPlaying, isMuted, volume, isTheaterMode, isFullscreen]);

  // Load saved progress when video changes
  useEffect(() => {
    if (!videoId) return;
    
    const history = JSON.parse(localStorage.getItem('videoHistory') || '[]');
    const videoProgress = history.find(v => v.id === videoId);
    
    if (videoProgress && videoProgress.currentTime < videoProgress.duration - 5) {
      setShouldResumeTime(videoProgress.currentTime);
    }
  }, [videoId]);

  // Resume playback if needed
  useEffect(() => {
    if (shouldResumeTime !== null && videoRef.current) {
      videoRef.current.currentTime = shouldResumeTime;
      setShouldResumeTime(null);
    }
  }, [shouldResumeTime]);

  // Event handlers
  const handlePlay = () => {
    setIsPlaying(true);
    log("play");
  };

  const handlePause = () => {
    setIsPlaying(false);
    log("pause");
  };

  const handleTimeUpdate = (e) => {
    const currentTime = e.target.currentTime;
    const duration = e.target.duration;
    
    setCurrentTime(currentTime);
    
    // Save progress every 5 seconds
    if (Math.abs(currentTime - lastSavedTime) > 5) {
      const history = JSON.parse(localStorage.getItem('videoHistory') || '[]');
      console.log('Current video history:', history);
      
      const updatedHistory = history.filter(v => v.id !== videoId);
      updatedHistory.unshift({
        id: videoId,
        title,
        thumbnail,
        currentTime,
        duration,
        lastWatched: Date.now()
      });
      
      // Keep only last 20 videos
      if (updatedHistory.length > 20) {
        updatedHistory.pop();
      }
      
      localStorage.setItem('videoHistory', JSON.stringify(updatedHistory));
      console.log('Saved video history:', updatedHistory);
      setLastSavedTime(currentTime);
      
      // Notify parent component
      if (onTimeUpdate) {
        onTimeUpdate(currentTime, duration);
      }
    }
    
    log("timeupdate", { currentTime });
  };

  const handleLoadedMetadata = (e) => {
    setDuration(e.target.duration);
    log("loadedmetadata", { duration: e.target.duration });
  };

  const handleVolumeChange = (e) => {
    setVolume(e.target.volume);
    setIsMuted(e.target.muted);
    log("volumechange", {
      volume: e.target.volume,
      muted: e.target.muted,
    });
  };

  const handleEnded = () => {
    setIsPlaying(false);
    
    const history = JSON.parse(localStorage.getItem('videoHistory') || '[]');
    const updatedHistory = history.map(v => {
      if (v.id === videoId) {
        return {
          ...v,
          currentTime: v.duration,
          lastWatched: Date.now()
        };
      }
      return v;
    });
    
    localStorage.setItem('videoHistory', JSON.stringify(updatedHistory));
    log("ended");
  };

  // Custom controls
  const togglePlay = () => {
    if (videoRef.current.paused) {
      videoRef.current.play();
    } else {
      videoRef.current.pause();
    }
  };

  const toggleMute = () => {
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const changeVolume = (e) => {
    const value = parseFloat(e.target.value);
    videoRef.current.volume = value;
    setVolume(value);
    setIsMuted(value === 0);
  };

  const seek = (e) => {
    const value = parseFloat(e.target.value);
    videoRef.current.currentTime = value;
    setCurrentTime(value);
  };

  const skipForward = () => {
    videoRef.current.currentTime += 10;
  };

  const skipBackward = () => {
    videoRef.current.currentTime -= 10;
  };

  const toggleTheaterMode = () => {
    setIsTheaterMode(!isTheaterMode);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const changePlaybackSpeed = (speed) => {
    videoRef.current.playbackRate = speed;
    setPlaybackSpeed(speed);
    setIsSettingsOpen(false);
  };

  const changeQuality = (newQuality) => {
    setQuality(newQuality);
    setIsSettingsOpen(false);
    // In a real implementation, you would switch video sources here
    log("qualitychange", { quality: newQuality });
  };

  // Share functionality
  const handleShare = async (platform) => {
    const videoUrl = window.location.href;
    const encodedUrl = encodeURIComponent(videoUrl);
    
    switch (platform) {
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`, '_blank');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?url=${encodedUrl}`, '_blank');
        break;
      case 'linkedin':
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`, '_blank');
        break;
      case 'copy':
        try {
          await navigator.clipboard.writeText(videoUrl);
          setShowCopyConfirmation(true);
          setTimeout(() => setShowCopyConfirmation(false), 2000);
        } catch (err) {
          console.error('Failed to copy:', err);
        }
        break;
      case 'embed':
        const embedCode = `<iframe width="560" height="315" src="${videoUrl}" frameborder="0" allowfullscreen></iframe>`;
        try {
          await navigator.clipboard.writeText(embedCode);
          setShowCopyConfirmation(true);
          setTimeout(() => setShowCopyConfirmation(false), 2000);
        } catch (err) {
          console.error('Failed to copy embed code:', err);
        }
        break;
    }
    
    if (platform !== 'copy' && platform !== 'embed') {
      setIsShareMenuOpen(false);
    }
  };

  // Helper function for tooltips
  const renderTooltip = (text, position) => {
    if (!hoveredControl || !text) return null;
    
    return (
      <div style={{
        position: 'absolute',
        bottom: position === 'bottom' ? '-35px' : '40px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(28, 28, 28, 0.9)',
        color: 'white',
        padding: '6px 10px',
        borderRadius: '4px',
        fontSize: '13px',
        fontWeight: '400',
        whiteSpace: 'nowrap',
        zIndex: 1000,
        fontFamily: "'Roboto', sans-serif",
        letterSpacing: '0.2px',
        pointerEvents: 'none'
      }}>
        {text}
      </div>
    );
  };

  // Add keyboard shortcuts overlay
  const renderKeyboardShortcuts = () => {
    if (!showKeyboardShortcuts) return null;

    return (
      <div style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        background: 'rgba(28, 28, 28, 0.95)',
        padding: '24px',
        borderRadius: '8px',
        color: 'white',
        fontFamily: "'Roboto', sans-serif",
        zIndex: 2000,
        maxHeight: '80vh',
        overflowY: 'auto',
        width: '500px',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.5)'
      }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          marginBottom: '20px'
        }}>
          <h2 style={{ margin: 0, fontSize: '20px', fontWeight: '500' }}>Keyboard shortcuts</h2>
          <button
            onClick={() => setShowKeyboardShortcuts(false)}
            style={{
              background: 'none',
              border: 'none',
              color: 'white',
              cursor: 'pointer',
              fontSize: '24px',
              padding: '4px'
            }}
          >
            <FaTimes />
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <div>
            <h3 style={{ fontSize: '16px', color: '#aaa', marginBottom: '12px' }}>Playback</h3>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              <li style={{ marginBottom: '8px' }}>Space/K - Play/Pause</li>
              <li style={{ marginBottom: '8px' }}>J - Rewind 10 seconds</li>
              <li style={{ marginBottom: '8px' }}>L - Forward 10 seconds</li>
              <li style={{ marginBottom: '8px' }}>← - Rewind 5 seconds</li>
              <li style={{ marginBottom: '8px' }}>→ - Forward 5 seconds</li>
              <li style={{ marginBottom: '8px' }}>, - Decrease speed</li>
              <li style={{ marginBottom: '8px' }}>. - Increase speed</li>
            </ul>
          </div>
          <div>
            <h3 style={{ fontSize: '16px', color: '#aaa', marginBottom: '12px' }}>General</h3>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              <li style={{ marginBottom: '8px' }}>F - Fullscreen</li>
              <li style={{ marginBottom: '8px' }}>T - Theater mode</li>
              <li style={{ marginBottom: '8px' }}>M - Mute</li>
              <li style={{ marginBottom: '8px' }}>↑ - Volume up</li>
              <li style={{ marginBottom: '8px' }}>↓ - Volume down</li>
              <li style={{ marginBottom: '8px' }}>0-9 - Seek to %</li>
              <li style={{ marginBottom: '8px' }}>? - Show shortcuts</li>
            </ul>
          </div>
        </div>
      </div>
    );
  };

  // Update handleProgressHover to only show timestamp
  const handleProgressHover = (e) => {
    if (!progressBarRef.current || !videoRef.current) return;

    const rect = progressBarRef.current.getBoundingClientRect();
    const position = e.clientX - rect.left;
    const percentage = position / rect.width;
    const timeValue = videoRef.current.duration * percentage;

    setHoverPosition(position);
    setHoverTime(timeValue);
  };

  // Update handleProgressLeave
  const handleProgressLeave = () => {
    setHoverPosition(null);
    setHoverTime(null);
  };

  // Add mini player toggle function
  const toggleMiniPlayer = () => {
    setIsMiniPlayer(!isMiniPlayer);
    // Exit theater mode and fullscreen when entering mini player
    if (!isMiniPlayer) {
      setIsTheaterMode(false);
      if (document.fullscreenElement) {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  return (
    <div 
      ref={containerRef}
      style={{ 
        maxWidth: isTheaterMode ? '100%' : '800px',
        width: isMiniPlayer ? '320px' : '100%',
        height: isMiniPlayer ? '180px' : 'auto',
        margin: isMiniPlayer ? '0' : "auto",
        position: isMiniPlayer ? "fixed" : "relative",
        bottom: isMiniPlayer ? "20px" : "auto",
        right: isMiniPlayer ? "20px" : "auto",
        background: "#000",
        borderRadius: isTheaterMode ? '0' : '8px',
        overflow: "hidden",
        aspectRatio: isMiniPlayer ? "unset" : "16/9",
        fontFamily: "'Roboto', sans-serif",
        zIndex: isMiniPlayer ? 9999 : 1,
        boxShadow: isMiniPlayer ? '0 4px 8px rgba(0,0,0,0.3)' : 'none',
        transition: 'all 0.3s ease',
        cursor: isMiniPlayer ? 'move' : 'default'
      }}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      onMouseMove={() => {
        setIsHovering(true);
        setShowControls(true);
      }}
      draggable={isMiniPlayer}
      onDragStart={(e) => {
        // Store the initial mouse position
        e.dataTransfer.setData('text/plain', '');
        const rect = e.currentTarget.getBoundingClientRect();
        e.currentTarget.dataset.offsetX = e.clientX - rect.left;
        e.currentTarget.dataset.offsetY = e.clientY - rect.top;
      }}
      onDrag={(e) => {
        if (!e.clientX || !e.clientY) return; // Ignore invalid drag events
        
        const container = containerRef.current;
        if (!container) return;

        const offsetX = parseFloat(container.dataset.offsetX) || 0;
        const offsetY = parseFloat(container.dataset.offsetY) || 0;
        
        // Calculate new position
        let left = e.clientX - offsetX;
        let top = e.clientY - offsetY;
        
        // Keep within viewport bounds
        const maxX = window.innerWidth - container.offsetWidth;
        const maxY = window.innerHeight - container.offsetHeight;
        
        left = Math.max(0, Math.min(left, maxX));
        top = Math.max(0, Math.min(top, maxY));
        
        container.style.right = `${window.innerWidth - left - container.offsetWidth}px`;
        container.style.bottom = `${window.innerHeight - top - container.offsetHeight}px`;
      }}
    >
      <video
        ref={videoRef}
        src={videoSrc}
        style={{ width: "100%", height: "100%", display: "block" }}
        onClick={togglePlay}
        onPlay={handlePlay}
        onPause={handlePause}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onVolumeChange={handleVolumeChange}
        onEnded={handleEnded}
      />
      
      {/* YouTube-style overlay for click to play */}
      {!isPlaying && (
        <div
          onClick={togglePlay}
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            background: "rgba(0,0,0,0.6)",
            borderRadius: "50%",
            width: "60px",
            height: "60px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer"
          }}
        >
          <FaPlay style={{ color: "white", fontSize: "24px" }} />
        </div>
      )}

      {/* Controls overlay */}
      <div style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        background: "linear-gradient(transparent, rgba(0,0,0,0.8))",
        padding: "40px 15px 10px",
        transition: "opacity 0.3s ease",
        opacity: showControls ? 1 : 0,
        pointerEvents: showControls ? "auto" : "none",
        fontFamily: "'Roboto', sans-serif"
      }}>
        {/* Progress bar container */}
        <div 
          ref={progressBarRef}
          style={{ 
            position: "relative", 
            marginBottom: "10px",
            padding: "10px 0",
            cursor: "pointer"
          }}
          onMouseMove={handleProgressHover}
          onMouseLeave={handleProgressLeave}
        >
          {/* Timestamp tooltip */}
          {hoverTime !== null && hoverPosition !== null && (
            <div style={{
              position: 'absolute',
              bottom: '40px',
              left: `${hoverPosition}px`,
              transform: 'translateX(-50%)',
              background: 'rgba(28, 28, 28, 0.9)',
              color: 'white',
              padding: '4px 8px',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: '500',
              zIndex: 1000,
              fontFamily: "'Roboto', sans-serif",
              whiteSpace: 'nowrap'
            }}>
              {formatTime(hoverTime)}
            </div>
          )}

          {/* Progress bar */}
          <input
            type="range"
            min="0"
            max={duration}
            step="0.1"
            value={currentTime}
            onChange={seek}
            style={{
              width: "100%",
              height: "3px",
              WebkitAppearance: "none",
              background: `linear-gradient(to right, #ff0000 ${(currentTime / duration) * 100}%, rgba(255,255,255,0.3) ${(currentTime / duration) * 100}%)`,
              cursor: "pointer",
              border: "none",
              borderRadius: "1.5px",
              transition: "height 0.1s ease",
              "&:hover": {
                height: "5px"
              }
            }}
          />
        </div>

        {/* Time display */}
        <span style={{ 
          fontSize: "14px",
          fontWeight: "500",
          letterSpacing: "0.3px",
          color: "rgba(255, 255, 255, 0.7)",
          marginLeft: "10px"
        }}>
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>

        {/* Controls row */}
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "20px",
          color: "white"
        }}>
          {/* Left controls */}
          <div style={{ display: "flex", alignItems: "center", gap: "15px", position: 'relative' }}>
            <div style={{ position: 'relative' }}>
              <button 
                onClick={togglePlay}
                className="control-button"
                onMouseEnter={() => setHoveredControl('play')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                {isPlaying ? <FaPause /> : <FaPlay />}
              </button>
              {hoveredControl === 'play' && renderTooltip(isPlaying ? 'Pause' : 'Play')}
            </div>

            <div style={{ position: 'relative' }}>
              <button 
                onClick={skipBackward}
                className="control-button"
                onMouseEnter={() => setHoveredControl('backward')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                <FaBackward />
              </button>
              {hoveredControl === 'backward' && renderTooltip('Rewind 10 seconds')}
            </div>

            <div style={{ position: 'relative' }}>
              <button 
                onClick={skipForward}
                className="control-button"
                onMouseEnter={() => setHoveredControl('forward')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                <FaForward />
              </button>
              {hoveredControl === 'forward' && renderTooltip('Forward 10 seconds')}
            </div>

            <div style={{ 
              display: "flex", 
              alignItems: "center", 
              gap: "8px", 
              minWidth: "140px", 
              position: 'relative' 
            }}>
              <button 
                onClick={toggleMute}
                className="control-button"
                onMouseEnter={() => setHoveredControl('volume')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                {isMuted ? <FaVolumeMute /> : <FaVolumeUp />}
              </button>
              {hoveredControl === 'volume' && renderTooltip(isMuted ? 'Unmute' : 'Mute')}
              <div style={{
                position: 'relative',
                width: '80px',
                height: '24px',
                display: 'flex',
                alignItems: 'center'
              }}>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={changeVolume}
                  style={{
                    width: "100%",
                    WebkitAppearance: "none",
                    background: `linear-gradient(to right, white ${volume * 100}%, rgba(255,255,255,0.3) ${volume * 100}%)`,
                    cursor: "pointer",
                    height: "3px",
                    borderRadius: "1.5px",
                    outline: "none",
                    margin: 0
                  }}
                />
              </div>
            </div>
          </div>

          {/* Right controls */}
          <div style={{ 
            display: "flex", 
            alignItems: "center", 
            gap: "15px",
            marginLeft: "auto"
          }}>
            {/* Add mini player button before theater mode */}
            <div style={{ position: 'relative' }}>
              <button 
                onClick={toggleMiniPlayer}
                className="control-button"
                onMouseEnter={() => setHoveredControl('miniplayer')}
                onMouseLeave={() => setHoveredControl(null)}
                style={{
                  fontSize: '18px',
                  padding: '6px'
                }}
              >
                <FaWindowRestore />
              </button>
              {hoveredControl === 'miniplayer' && renderTooltip(isMiniPlayer ? 'Exit mini player' : 'Mini player')}
            </div>

            {/* Share Button and Menu */}
            <div style={{ position: "relative" }} ref={shareMenuRef}>
              <button 
                onClick={() => setIsShareMenuOpen(!isShareMenuOpen)}
                className="control-button"
                onMouseEnter={() => setHoveredControl('share')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                <FaShare />
              </button>
              {hoveredControl === 'share' && !isShareMenuOpen && renderTooltip('Share')}

              {isShareMenuOpen && (
                <div
                  style={{
                    position: "absolute",
                    bottom: "100%",
                    right: "0",
                    background: "rgba(28,28,28,0.9)",
                    borderRadius: "4px",
                    padding: "16px",
                    marginBottom: "10px",
                    minWidth: "250px",
                    boxShadow: "0 2px 10px rgba(0,0,0,0.3)",
                    fontFamily: "'Roboto', sans-serif"
                  }}
                >
                  <div style={{ 
                    display: "flex", 
                    justifyContent: "space-between", 
                    alignItems: "center",
                    marginBottom: "12px"
                  }}>
                    <h3 style={{ 
                      margin: 0, 
                      fontSize: "16px",
                      fontWeight: "500",
                      letterSpacing: "0.3px"
                    }}>Share</h3>
                    <button
                      onClick={() => setIsShareMenuOpen(false)}
                      style={{
                        background: "none",
                        border: "none",
                        color: "white",
                        cursor: "pointer",
                        padding: "4px"
                      }}
                    >
                      <FaTimes />
                    </button>
                  </div>

                  <div style={{ 
                    display: "flex", 
                    gap: "12px", 
                    marginBottom: "16px",
                    justifyContent: "center"
                  }}>
                    <button
                      onClick={() => handleShare('facebook')}
                      className="share-button"
                      style={{ background: "#1877f2" }}
                    >
                      <FaFacebookF />
                    </button>
                    <button
                      onClick={() => handleShare('twitter')}
                      className="share-button"
                      style={{ background: "#1da1f2" }}
                    >
                      <FaTwitter />
                    </button>
                    <button
                      onClick={() => handleShare('linkedin')}
                      className="share-button"
                      style={{ background: "#0a66c2" }}
                    >
                      <FaLinkedinIn />
                    </button>
                  </div>

                  <button
                    onClick={() => handleShare('copy')}
                    className="share-option-button"
                  >
                    <FaLink />
                    <span>Copy link</span>
                  </button>

                  <button
                    onClick={() => handleShare('embed')}
                    className="share-option-button"
                  >
                    <FaCode />
                    <span>Embed</span>
                  </button>

                  {showCopyConfirmation && (
                    <div style={{
                      position: "absolute",
                      bottom: "-40px",
                      left: "50%",
                      transform: "translateX(-50%)",
                      background: "rgba(28,28,28,0.9)",
                      padding: "8px 12px",
                      borderRadius: "4px",
                      whiteSpace: "nowrap",
                      fontSize: "13px",
                      fontWeight: "400",
                      letterSpacing: "0.2px"
                    }}>
                      Copied to clipboard!
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Settings menu */}
            <div style={{ position: "relative" }}>
              <button 
                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                className="control-button"
                onMouseEnter={() => setHoveredControl('settings')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                <FaCog />
              </button>
              {hoveredControl === 'settings' && !isSettingsOpen && renderTooltip('Settings')}
              
              {isSettingsOpen && (
                <div style={{
                  position: "absolute",
                  bottom: "100%",
                  right: "0",
                  background: "rgba(28,28,28,0.9)",
                  borderRadius: "4px",
                  padding: "8px 0",
                  marginBottom: "10px",
                  minWidth: "200px",
                  fontFamily: "'Roboto', sans-serif"
                }}>
                  <div style={{ padding: "8px 16px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
                    <p style={{ 
                      margin: "0 0 8px", 
                      color: "rgba(255,255,255,0.7)",
                      fontSize: "13px",
                      fontWeight: "500",
                      letterSpacing: "0.2px"
                    }}>Playback Speed</p>
                    {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2].map((speed) => (
                      <button
                        key={speed}
                        onClick={() => changePlaybackSpeed(speed)}
                        style={{
                          display: "block",
                          width: "100%",
                          textAlign: "left",
                          padding: "4px 0",
                          background: "none",
                          border: "none",
                          color: playbackSpeed === speed ? "#ff0000" : "white",
                          cursor: "pointer"
                        }}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>
                  <div style={{ padding: "8px 16px" }}>
                    <p style={{ 
                      margin: "0 0 8px", 
                      color: "rgba(255,255,255,0.7)",
                      fontSize: "13px",
                      fontWeight: "500",
                      letterSpacing: "0.2px"
                    }}>Quality</p>
                    {['auto', '1080p', '720p', '480p', '360p'].map((q) => (
                      <button
                        key={q}
                        onClick={() => changeQuality(q)}
                        style={{
                          display: "block",
                          width: "100%",
                          textAlign: "left",
                          padding: "4px 0",
                          background: "none",
                          border: "none",
                          color: quality === q ? "#ff0000" : "white",
                          cursor: "pointer"
                        }}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div style={{ position: 'relative' }}>
              <button 
                onClick={toggleTheaterMode}
                className="control-button"
                onMouseEnter={() => setHoveredControl('theater')}
                onMouseLeave={() => setHoveredControl(null)}
                style={{
                  fontSize: '20px', // Slightly larger for better visibility
                  padding: '6px', // Adjusted padding for the new icon
                }}
              >
                {isTheaterMode ? <MdOutlineCropLandscape /> : <MdOutlineCropSquare />}
              </button>
              {hoveredControl === 'theater' && renderTooltip(isTheaterMode ? 'Default view' : 'Theater mode')}
            </div>

            <div style={{ position: 'relative' }}>
              <button 
                onClick={toggleFullscreen}
                className="control-button"
                onMouseEnter={() => setHoveredControl('fullscreen')}
                onMouseLeave={() => setHoveredControl(null)}
              >
                {isFullscreen ? <FaCompress /> : <FaExpand />}
              </button>
              {hoveredControl === 'fullscreen' && renderTooltip(isFullscreen ? 'Exit full screen' : 'Full screen')}
            </div>
          </div>
        </div>
      </div>

      {/* Keyboard shortcuts overlay */}
      {renderKeyboardShortcuts()}

      {/* Add mini player close button */}
      {isMiniPlayer && (
        <button
          onClick={toggleMiniPlayer}
          style={{
            position: 'absolute',
            top: '8px',
            right: '8px',
            background: 'rgba(0, 0, 0, 0.7)',
            border: 'none',
            color: 'white',
            padding: '4px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            opacity: showControls ? 1 : 0,
            transition: 'opacity 0.3s ease'
          }}
        >
          <FaTimes />
        </button>
      )}

      {/* Add drag handle indicator for mini player */}
      {isMiniPlayer && showControls && (
        <div style={{
          position: 'absolute',
          top: '8px',
          left: '8px',
          background: 'rgba(255, 255, 255, 0.3)',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '12px',
          color: 'white',
          pointerEvents: 'none'
        }}>
          Drag to move
        </div>
      )}

      <style>
        {`
          .control-button {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            padding: 8px;
            display: flex;
            align-items: center;
            font-size: 16px;
            transition: color 0.2s ease;
            font-family: 'Roboto', sans-serif;
            font-weight: 400;
            position: relative;
          }
          .control-button:hover {
            color: #ff0000;
          }
          .share-button {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.2s ease;
            font-family: 'Roboto', sans-serif;
          }
          .share-button:hover {
            transform: scale(1.1);
          }
          .share-option-button {
            width: 100%;
            padding: 8px 12px;
            background: none;
            border: none;
            color: white;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            border-radius: 4px;
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
            font-weight: 400;
            letter-spacing: 0.2px;
          }
          .share-option-button:hover {
            background: rgba(255,255,255,0.1);
          }
          .menu-item {
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
            font-weight: 400;
            letter-spacing: 0.2px;
          }
          input[type="range"] {
            -webkit-appearance: none;
            appearance: none;
            background: transparent;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
          }
          input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: white;
            cursor: pointer;
            margin-top: -4.5px;
            transition: transform 0.1s ease;
          }
          input[type="range"]::-moz-range-thumb {
            width: 12px;
            height: 12px;
            border: none;
            border-radius: 50%;
            background: white;
            cursor: pointer;
            transition: transform 0.1s ease;
          }
          input[type="range"]::-webkit-slider-runnable-track {
            width: 100%;
            height: 3px;
            cursor: pointer;
            border-radius: 1.5px;
          }
          input[type="range"]::-moz-range-track {
            width: 100%;
            height: 3px;
            cursor: pointer;
            border-radius: 1.5px;
          }
          input[type="range"]:focus {
            outline: none;
          }
          input[type="range"]:hover::-webkit-slider-thumb {
            transform: scale(1.2);
          }
          input[type="range"]:hover::-moz-range-thumb {
            transform: scale(1.2);
          }
          @keyframes tooltipFade {
            from {
              opacity: 0;
              transform: translate(-50%, 5px);
            }
            to {
              opacity: 1;
              transform: translate(-50%, 0);
            }
          }
          .tooltip {
            animation: tooltipFade 0.2s ease;
          }
        `}
      </style>
    </div>
  );
};

export default VideoPlayer;