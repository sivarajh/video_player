import React, { useState } from 'react';
import VideoPlayer from './VideoPlayer';
import Dashboard from './Dashboard';

// Example video data with multiple formats and sources
const videos = [
  {
    id: '1',
    title: 'Big Buck Bunny',
    src: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumbnail: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg'
  },
  {
    id: '2',
    title: 'Elephant Dream',
    src: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumbnail: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg'
  },
  {
    id: '3',
    title: 'Sintel',
    src: 'https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    thumbnail: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg'
  }
];

const App = () => {
  const [selectedVideo, setSelectedVideo] = useState(null); // Start with no video selected

  const handleVideoSelect = (video) => {
    setSelectedVideo(video);
    window.scrollTo(0, 0);
  };

  const handleTimeUpdate = (currentTime, duration) => {
    // You can add additional handling here if needed
    console.log('Video progress:', { currentTime, duration });
  };

  return (
    <div style={{
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '20px',
      background: '#f9f9f9',
      minHeight: '100vh',
      fontFamily: "'Roboto', sans-serif"
    }}>
      {selectedVideo ? (
        <div style={{ marginBottom: '40px' }}>
          <VideoPlayer
            videoId={selectedVideo.id}
            videoSrc={selectedVideo.src}
            title={selectedVideo.title}
            thumbnail={selectedVideo.thumbnail}
            onTimeUpdate={handleTimeUpdate}
          />
          <h1 style={{
            fontSize: '24px',
            fontWeight: '500',
            margin: '20px 0',
            color: '#1a1a1a'
          }}>
            {selectedVideo.title}
          </h1>
          <button 
            onClick={() => setSelectedVideo(null)}
            style={{
              background: '#f0f0f0',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px',
              color: '#666',
              marginBottom: '20px'
            }}
          >
            Back to Dashboard
          </button>
        </div>
      ) : (
        <div style={{
          textAlign: 'center',
          padding: '40px',
          background: '#fff',
          borderRadius: '8px',
          marginBottom: '40px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h1 style={{
            fontSize: '28px',
            fontWeight: '500',
            marginBottom: '16px',
            color: '#1a1a1a'
          }}>
            Welcome to IQ Sales Enablement Training
          </h1>
          <p style={{
            fontSize: '16px',
            color: '#666',
            maxWidth: '600px',
            margin: '0 auto'
          }}>
            Browse through our training videos below. Your progress will appear in the "Continue Watching" section.
          </p>
        </div>
      )}

      <Dashboard 
        onVideoSelect={handleVideoSelect} 
        videos={videos}
      />
    </div>
  );
};

export default App; 