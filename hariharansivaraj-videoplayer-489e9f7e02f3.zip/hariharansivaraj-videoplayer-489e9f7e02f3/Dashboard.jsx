import React, { useEffect, useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

const Dashboard = ({ onVideoSelect, videos }) => {
  const [videoHistory, setVideoHistory] = useState([]);

  useEffect(() => {
    // Load video history from localStorage
    const loadHistory = () => {
      const history = JSON.parse(localStorage.getItem('videoHistory') || '[]');
      console.log('Loading video history:', history);
      setVideoHistory(history.sort((a, b) => b.lastWatched - a.lastWatched));
    };

    loadHistory();
    // Listen for storage changes from other tabs
    window.addEventListener('storage', loadHistory);
    return () => window.removeEventListener('storage', loadHistory);
  }, []);

  // Add debug log when videoHistory changes
  useEffect(() => {
    console.log('Video history state updated:', videoHistory);
  }, [videoHistory]);

  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const calculateProgress = (currentTime, duration) => {
    return Math.round((currentTime / duration) * 100);
  };

  return (
    <div style={{
      padding: '20px',
      maxWidth: '1200px',
      margin: '0 auto',
      fontFamily: "'Roboto', sans-serif"
    }}>
      <h2 style={{
        fontSize: '24px',
        fontWeight: '500',
        marginBottom: '20px',
        color: '#1a1a1a'
      }}>
        Continue Watching
      </h2>
      
      <div style={{
        display: 'grid',
        gap: '16px',
        gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
        marginBottom: '40px'
      }}>
        {videoHistory.length > 0 ? (
          videoHistory.map((video) => (
            <div
              key={video.id}
              style={{
                background: '#fff',
                borderRadius: '8px',
                overflow: 'hidden',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                cursor: 'pointer',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                }
              }}
              onClick={() => onVideoSelect(videos.find(v => v.id === video.id))}
            >
              {/* Thumbnail */}
              <div style={{
                position: 'relative',
                paddingTop: '56.25%', // 16:9 aspect ratio
                background: '#f0f0f0'
              }}>
                {video.thumbnail && (
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover'
                    }}
                  />
                )}
                
                {/* Progress bar */}
                <div style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: '4px',
                  background: 'rgba(255,255,255,0.3)'
                }}>
                  <div style={{
                    height: '100%',
                    background: '#ff0000',
                    width: `${calculateProgress(video.currentTime, video.duration)}%`
                  }} />
                </div>

                {/* Percentage indicator */}
                <div style={{
                  position: 'absolute',
                  top: '8px',
                  right: '8px',
                  background: 'rgba(0, 0, 0, 0.75)',
                  color: 'white',
                  padding: '4px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: '500'
                }}>
                  {calculateProgress(video.currentTime, video.duration)}% watched
                </div>
              </div>

              {/* Video info */}
              <div style={{ padding: '12px' }}>
                <h3 style={{
                  margin: '0 0 4px',
                  fontSize: '16px',
                  fontWeight: '500',
                  color: '#1a1a1a',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap'
                }}>
                  {video.title}
                </h3>
                
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '13px',
                  color: '#666'
                }}>
                  <span>{formatDuration(video.currentTime)} / {formatDuration(video.duration)}</span>
                  <span>{formatDistanceToNow(video.lastWatched, { addSuffix: true })}</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div style={{
            gridColumn: '1 / -1',
            padding: '32px',
            background: '#fff',
            borderRadius: '8px',
            textAlign: 'center',
            color: '#666',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <p>No videos in watch history yet. Start watching a video to see it here!</p>
          </div>
        )}
      </div>

      <h2 style={{
        fontSize: '24px',
        fontWeight: '500',
        marginBottom: '20px',
        color: '#1a1a1a'
      }}>
        All Videos
      </h2>
      
      <div style={{
        display: 'grid',
        gap: '16px',
        gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))'
      }}>
        {videos.map((video) => (
          <div
            key={video.id}
            style={{
              background: '#fff',
              borderRadius: '8px',
              overflow: 'hidden',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease',
              cursor: 'pointer',
              '&:hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
              }
            }}
            onClick={() => onVideoSelect(video)}
          >
            {/* Thumbnail */}
            <div style={{
              position: 'relative',
              paddingTop: '56.25%', // 16:9 aspect ratio
              background: '#f0f0f0'
            }}>
              <img
                src={video.thumbnail}
                alt={video.title}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover'
                }}
              />
            </div>

            {/* Video info */}
            <div style={{ padding: '12px' }}>
              <h3 style={{
                margin: '0',
                fontSize: '16px',
                fontWeight: '500',
                color: '#1a1a1a',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              }}>
                {video.title}
              </h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard; 