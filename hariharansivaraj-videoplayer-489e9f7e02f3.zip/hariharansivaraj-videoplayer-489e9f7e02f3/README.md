# React Video Player Starter

This is a minimal React project to run the `VideoPlayer` component with full user interaction logging.

## Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the development server:**
   ```bash
   npm run dev
   ```

3. **Open your browser:**
   Visit [http://localhost:5173](http://localhost:5173) (or the URL shown in your terminal).

## Project Structure

- `VideoPlayer.jsx` — The custom video player React component
- `main.jsx` — App entry point, renders the video player
- `index.html` — HTML template
- `package.json` — Project dependencies and scripts

---

You can now use this as a base for further development! 